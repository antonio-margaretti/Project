import sys
from PyQt5.QtWidgets import QApplication

from config import Config
from gui import PoemApp


def main():
    # Проверяем наличие API ключа (выводит предупреждение, если нет)
    Config.print_api_status()
    
    # Создаем приложение
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # Создаем и показываем главное окно
    window = PoemApp()
    window.show()
    
    # Запускаем главный цикл
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()