import sys
import os
import random
from datetime import datetime
import requests
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QLabel, QPushButton, QFrame)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QColor, QLinearGradient, QPainter

class GradientWidget(QWidget):
    """Виджет с градиентным фоном"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.gradient_rotation = 0
        
    def paintEvent(self, event):
        painter = QPainter(self)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        
        # Мягкие, спокойные цвета в зависимости от времени суток
        hour = datetime.now().hour
        if 5 <= hour < 12:  # Утро
            gradient.setColorAt(0, QColor(255, 243, 224))  # Светло-персиковый
            gradient.setColorAt(1, QColor(255, 218, 185))  # Персиковый
        elif 12 <= hour < 17:  # День
            gradient.setColorAt(0, QColor(240, 248, 255))  # Светло-голубой
            gradient.setColorAt(1, QColor(176, 224, 230))  # Нежно-голубой
        elif 17 <= hour < 23:  # Вечер
            gradient.setColorAt(0, QColor(255, 228, 225))  # Светло-розовый
            gradient.setColorAt(1, QColor(255, 182, 193))  # Розовый
        else:  # Ночь
            gradient.setColorAt(0, QColor(25, 25, 112))  # Темно-синий
            gradient.setColorAt(1, QColor(72, 61, 139))  # Темно-фиолетовый
            
        painter.fillRect(self.rect(), gradient)

class PoemApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Момент тишины")
        self.setGeometry(100, 100, 700, 600)
        
        # Убираем стандартные рамки окна для создания атмосферы
        self.setWindowFlags(Qt.FramelessWindowHint)
        
        # Центральный виджет с градиентом
        self.central_widget = GradientWidget()
        self.setCentralWidget(self.central_widget)
        
        # Основной layout
        main_layout = QVBoxLayout(self.central_widget)
        main_layout.setContentsMargins(50, 50, 50, 50)
        main_layout.setSpacing(30)
        
        # Верхняя панель с кнопкой закрытия
        top_panel = QWidget()
        top_panel.setStyleSheet("background-color: rgba(255, 255, 255, 100); border-radius: 15px;")
        top_layout = QHBoxLayout(top_panel)
        
        # Добавляем пустой виджет слева для баланса
        left_spacer = QWidget()
        left_spacer.setFixedWidth(30)  # Такая же ширина как у кнопки закрытия
        top_layout.addWidget(left_spacer)
        
        top_layout.addStretch()
        
        # Кнопка закрытия
        close_btn = QPushButton("✕")
        close_btn.setFont(QFont("Helvetica", 14))
        close_btn.setFixedSize(30, 30)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 150);
                border: none;
                border-radius: 15px;
                color: #2F4F4F;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 200);
            }
        """)
        close_btn.clicked.connect(self.close)
        top_layout.addWidget(close_btn)
        
        main_layout.addWidget(top_panel)
        
        main_layout.addStretch()
        
        # Контейнер для стиха
        poem_container = QFrame()
        poem_container.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 150);
                border-radius: 30px;
                padding: 30px;
            }
        """)
        poem_layout = QVBoxLayout(poem_container)
        
        # Заголовок
        title_label = QLabel("стихотворение момента")
        title_label.setFont(QFont("Helvetica", 10))
        title_label.setStyleSheet("color: #2F4F4F; letter-spacing: 2px;")
        title_label.setAlignment(Qt.AlignCenter)
        poem_layout.addWidget(title_label)
        
        # Текст стиха
        self.poem_text = QLabel()
        self.poem_text.setFont(QFont("Georgia", 14))
        self.poem_text.setStyleSheet("""
            QLabel {
                color: #2F4F4F;
                line-height: 1.8;
                padding: 20px;
            }
        """)
        self.poem_text.setAlignment(Qt.AlignCenter)
        self.poem_text.setWordWrap(True)
        poem_layout.addWidget(self.poem_text)
        
        main_layout.addWidget(poem_container)
        
        main_layout.addStretch()
        
        # Нижняя панель с кнопкой
        bottom_panel = QWidget()
        bottom_panel.setStyleSheet("background-color: rgba(255, 255, 255, 100); border-radius: 15px;")
        bottom_layout = QHBoxLayout(bottom_panel)
        
        # Добавляем пустой виджет слева для центрирования кнопки
        bottom_layout.addStretch()
        
        # Кнопка обновления
        refresh_btn = QPushButton("⟳ другой стих")
        refresh_btn.setFont(QFont("Helvetica", 11))
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 150);
                border: none;
                border-radius: 20px;
                padding: 10px 20px;
                color: #2F4F4F;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 200);
            }
        """)
        refresh_btn.clicked.connect(self.update_poem)
        bottom_layout.addWidget(refresh_btn)
        
        bottom_layout.addStretch()
        
        main_layout.addWidget(bottom_panel)
        
        # Первоначальная загрузка
        self.update_poem()
    
    def get_time_of_day(self):
        """Определяет время суток"""
        hour = datetime.now().hour
        if 5 <= hour < 12:
            return "morning"
        elif 12 <= hour < 17:
            return "day"
        elif 17 <= hour < 23:
            return "evening"
        else:
            return "night"
    
    def get_poem(self):
        """Выбирает стих на основе погоды и времени"""
        try:
            # Пытаемся получить погоду для выбора папки
            weather_desc, temp = self.get_weather()
            time_of_day = self.get_time_of_day()
            
            # Логика выбора папки
            if weather_desc and "дождь" in weather_desc.lower():
                folder = "rain"
            elif weather_desc and "снег" in weather_desc.lower():
                folder = "snow"
            elif weather_desc and ("ясно" in weather_desc.lower() or "солнечно" in weather_desc.lower()):
                folder = "clear"
            else:
                folder = time_of_day
        except:
            # Если не удалось получить погоду, используем время суток
            folder = self.get_time_of_day()
        
        # Путь к папке со стихами
        base_path = os.path.dirname(os.path.abspath(__file__))
        folder_path = os.path.join(base_path, "poems", folder)
        
        # Проверяем существование папки
        if not os.path.exists(folder_path):
            folder_path = os.path.join(base_path, "poems", "morning")
            if not os.path.exists(folder_path):
                return "Создайте папку 'poems' с подпапками: morning, day, evening, night, rain, snow, clear"
        
        # Получаем список файлов
        try:
            poem_files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
            if not poem_files:
                return f"В папке {folder} нет стихов. Добавьте .txt файлы!"
            
            chosen = random.choice(poem_files)
            
            with open(os.path.join(folder_path, chosen), "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"Ошибка при чтении стиха: {e}"
    
    def get_weather(self, city="Moscow"):
        """Получает погоду (используется только для выбора папки)"""
        api_key = "a78439007523cd5ea50a8dc974f91edb"
        
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": city,
            "appid": api_key,
            "units": "metric",
            "lang": "ru"
        }
        
        try:
            response = requests.get(url, params=params)
            data = response.json()
            
            if response.status_code == 200:
                weather_desc = data['weather'][0]['description']
                temperature = data['main']['temp']
                return weather_desc, temperature
            else:
                return None, 0
        except:
            return None, 0
    
    def update_poem(self):
        """Обновляет текст стиха"""
        poem_text = self.get_poem()
        self.poem_text.setText(poem_text)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Устанавливаем стиль для всего приложения
    app.setStyle('Fusion')
    
    window = PoemApp()
    window.show()
    
    sys.exit(app.exec_())