import os
import random
from datetime import datetime

from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QLabel, QPushButton, QFrame)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor, QLinearGradient, QPainter

from config import Config
from weather_api import WeatherService


class GradientWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        
        hour = datetime.now().hour
        if 5 <= hour < 12:  # Утро
            gradient.setColorAt(0, QColor(255, 243, 224))  # Светло-персиковый
            gradient.setColorAt(1, QColor(255, 218, 185))  # Персиковый
        elif 12 <= hour < 17:  # День
            gradient.setColorAt(0, QColor(240, 248, 255))  # Светло-голубой
            gradient.setColorAt(1, QColor(176, 224, 230))  # Нежно-голубой
        elif 17 <= hour < 23:  # Вечер
            gradient.setColorAt(0, QColor(255, 228, 225))  # Светло-розовый
            gradient.setColorAt(1, QColor(255, 182, 193))  # Розовый
        else:  # Ночь
            gradient.setColorAt(0, QColor(25, 25, 112))  # Темно-синий
            gradient.setColorAt(1, QColor(72, 61, 139))  # Темно-фиолетовый
            
        painter.fillRect(self.rect(), gradient)


class PoemApp(QMainWindow):
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_position = event.globalPos() - self.frameGeometry().topLeft()
            event.accept()
            
    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton:
            self.move(event.globalPos() - self.drag_position)
            event.accept()
            
    def __init__(self):
        super().__init__()
        
        # Инициализация сервисов
        self.weather_service = WeatherService()
        
        # Текущие данные
        self.current_weather = None
        self.current_temperature = None
        
        # Настройка окна
        self.setWindowTitle("Момент тишины")
        self.setGeometry(100, 100, Config.WINDOW_WIDTH, Config.WINDOW_HEIGHT)
        self.setWindowFlags(Qt.FramelessWindowHint)
        
        # Центральный виджет с градиентом
        self.central_widget = GradientWidget()
        self.setCentralWidget(self.central_widget)
        
        # Создание интерфейса
        self._setup_ui()
        
        # Загружаем первое стихотворение
        self.update_poem()
    
    def _setup_ui(self):
        main_layout = QVBoxLayout(self.central_widget)
        main_layout.setContentsMargins(50, 50, 50, 50)
        main_layout.setSpacing(30)
        
        # Верхняя панель с кнопкой закрытия
        self._setup_top_panel(main_layout)
        
        main_layout.addStretch()
        
        # Контейнер для стиха
        self._setup_poem_container(main_layout)
        
        main_layout.addStretch()
        
        # Нижняя панель с кнопкой
        self._setup_bottom_panel(main_layout)
    
    def _setup_top_panel(self, main_layout):
        top_panel = QWidget()
        top_panel.setStyleSheet(
            "background-color: rgba(255, 255, 255, 100); border-radius: 15px;"
        )
        top_layout = QHBoxLayout(top_panel)
        
        # Пустой виджет слева для баланса
        left_spacer = QWidget()
        left_spacer.setFixedWidth(30)
        top_layout.addWidget(left_spacer)
        
        top_layout.addStretch()
        
        # Кнопка закрытия
        close_btn = QPushButton("✕")
        close_btn.setFont(QFont("Helvetica", 14))
        close_btn.setFixedSize(30, 30)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 150);
                border: none;
                border-radius: 15px;
                color: #2F4F4F;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 200);
            }
        """)
        close_btn.clicked.connect(self.close)
        top_layout.addWidget(close_btn)
        
        main_layout.addWidget(top_panel)
    
    def _setup_poem_container(self, main_layout):
        poem_container = QFrame()
        poem_container.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 150);
                border-radius: 30px;
                padding: 30px;
            }
        """)
        poem_layout = QVBoxLayout(poem_container)
        
        # Заголовок
        title_label = QLabel("стихотворение момента")
        title_label.setFont(QFont("Helvetica", 10))
        title_label.setStyleSheet("color: #2F4F4F; letter-spacing: 2px;")
        title_label.setAlignment(Qt.AlignCenter)
        poem_layout.addWidget(title_label)
        
        # Текст стиха
        self.poem_text = QLabel()
        self.poem_text.setFont(QFont("Georgia", 14))
        self.poem_text.setStyleSheet("""
            QLabel {
                color: #2F4F4F;
                line-height: 1.8;
                padding: 20px;
            }
        """)
        self.poem_text.setAlignment(Qt.AlignCenter)
        self.poem_text.setWordWrap(True)
        poem_layout.addWidget(self.poem_text)
        
        main_layout.addWidget(poem_container)
    
    def _setup_bottom_panel(self, main_layout):
        bottom_panel = QWidget()
        bottom_panel.setStyleSheet(
            "background-color: rgba(255, 255, 255, 100); border-radius: 15px;"
        )
        bottom_layout = QHBoxLayout(bottom_panel)
        
        bottom_layout.addStretch()
        
        # Кнопка обновления
        refresh_btn = QPushButton("⟳ другой стих")
        refresh_btn.setFont(QFont("Helvetica", 11))
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 150);
                border: none;
                border-radius: 20px;
                padding: 10px 20px;
                color: #2F4F4F;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 200);
            }
        """)
        refresh_btn.clicked.connect(self.update_poem)
        bottom_layout.addWidget(refresh_btn)
        
        bottom_layout.addStretch()
        
        main_layout.addWidget(bottom_panel)
    
    def get_time_of_day(self):
        hour = datetime.now().hour
        if 5 <= hour < 12:
            return "morning"
        elif 12 <= hour < 17:
            return "day"
        elif 17 <= hour < 23:
            return "evening"
        else:
            return "night"
    
    def get_poem(self, folder=None):
        if folder is None:
            # Определяем папку на основе контекста
            time_of_day = self.get_time_of_day()
            
            if self.current_weather:
                # Учитываем погоду, если она есть
                weather_lower = self.current_weather.lower()
                if "дождь" in weather_lower:
                    folder = "rain"
                elif "снег" in weather_lower:
                    folder = "snow"
                elif "ясно" in weather_lower or "солнечно" in weather_lower:
                    folder = "clear"
                else:
                    folder = time_of_day
            else:
                # Без погоды используем только время суток
                folder = time_of_day
        
        # Путь к папке со стихами
        folder_path = Config.POEMS_PATH / folder
        
        # Проверяем существование папки
        if not folder_path.exists():
            folder_path = Config.POEMS_PATH / "morning"
            if not folder_path.exists():
                return (
                    "Создайте папку 'data/poems' с подпапками:\n"
                    "morning, day, evening, night, rain, snow, clear\n"
                    "и добавьте в них .txt файлы со стихами."
                )
        
        # Получаем список файлов
        try:
            poem_files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
            if not poem_files:
                return f"В папке {folder} нет стихов. Добавьте .txt файлы!"
            
            chosen = random.choice(poem_files)
            
            with open(os.path.join(folder_path, chosen), "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"Ошибка при чтении стиха: {e}"
    
    def update_poem(self):
        """Обновляет текст стихотворения."""
        # Показываем индикатор загрузки
        self.poem_text.setText("Загружаю...")
        
        # Запускаем асинхронное получение погоды
        self.weather_service.fetch_weather(
            callback_success=self._on_weather_success,
            callback_fail=self._on_weather_fail
        )
    
    def _on_weather_success(self, weather_desc, temperature):
        """
        Обрабатывает успешное получение погоды.
        
        Args:
            weather_desc: описание погоды
            temperature: температура
        """
        self.current_weather = weather_desc
        self.current_temperature = temperature
        
        # Выбираем стих с учетом погоды
        poem_text = self.get_poem()
        self.poem_text.setText(poem_text)
    
    def _on_weather_fail(self):
        """Обрабатывает ошибку получения погоды."""
        self.current_weather = None
        self.current_temperature = None
        
        # Выбираем стих только по времени суток
        poem_text = self.get_poem()
        self.poem_text.setText(poem_text)