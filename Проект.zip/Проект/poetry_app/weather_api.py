import requests
from PyQt5.QtCore import QThread, pyqtSignal

from config import Config

class WeatherWorker(QThread):
    # Сигналы для связи с главным окном
    weather_received = pyqtSignal(str, float)  # описание, температура
    weather_failed = pyqtSignal()  # ошибка или нет ключа
    
    def __init__(self, city=None):
        super().__init__()
        self.city = city or Config.DEFAULT_CITY
        self.api_key = Config.OPENWEATHER_API_KEY
        
    def run(self):
        # Если нет API ключа — сразу сообщаем об ошибке
        if not self.api_key:
            self.weather_failed.emit()
            return
        
        try:
            url = "https://api.openweathermap.org/data/2.5/weather"
            params = {
                "q": self.city,
                "appid": self.api_key,
                "units": "metric",
                "lang": "ru"
            }
            
            # Таймаут 3 секунды, чтобы не ждать слишком долго
            response = requests.get(url, params=params, timeout=3)
            
            if response.status_code == 200:
                data = response.json()
                weather_desc = data['weather'][0]['description']
                temperature = data['main']['temp']
                
                # Отправляем сигнал с данными
                self.weather_received.emit(weather_desc, temperature)
            else:
                # Ошибка API (неверный ключ, город не найден и т.д.)
                self.weather_failed.emit()
                
        except requests.exceptions.Timeout:
            # Таймаут запроса
            self.weather_failed.emit()
        except requests.exceptions.ConnectionError:
            # Нет подключения к интернету
            self.weather_failed.emit()
        except Exception:
            # Любая другая ошибка
            self.weather_failed.emit()


class WeatherService:
    def __init__(self):
        self.current_worker = None
        self.last_weather = None
        self.last_temperature = None
        
    def fetch_weather(self, callback_success=None, callback_fail=None, city=None):
        # Останавливаем предыдущий запрос, если он еще выполняется
        if self.current_worker and self.current_worker.isRunning():
            self.current_worker.terminate()
            self.current_worker.wait()
        
        # Создаем новый рабочий поток
        self.current_worker = WeatherWorker(city)
        
        # Подключаем сигналы к переданным функциям
        if callback_success:
            self.current_worker.weather_received.connect(
                lambda desc, temp: self._on_success(desc, temp, callback_success)
            )
        if callback_fail:
            self.current_worker.weather_failed.connect(
                lambda: self._on_fail(callback_fail)
            )
        
        # Запускаем поток
        self.current_worker.start()
    
    def _on_success(self, desc, temp, callback):
        self.last_weather = desc
        self.last_temperature = temp
        callback(desc, temp)
    
    def _on_fail(self, callback):
        callback()
    
    def get_last_weather(self):
        return self.last_weather, self.last_temperature