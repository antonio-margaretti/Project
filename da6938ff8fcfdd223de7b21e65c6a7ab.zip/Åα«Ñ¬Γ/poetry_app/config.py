import os
from pathlib import Path
from dotenv import load_dotenv

# Загружаем переменные из .env файла (если он есть в папке с программой)
env_path = Path(__file__).parent / '.env'
load_dotenv(env_path)

class Config:
    """Настройки приложения."""
    
    # API ключ для OpenWeatherMap (из переменной окружения или .env)
    OPENWEATHER_API_KEY = os.getenv('OPENWEATHER_API_KEY', '')
    
    # Город по умолчанию
    DEFAULT_CITY = os.getenv('WEATHER_CITY', 'Moscow')
    
    # Путь к папке со стихами
    POEMS_PATH = Path(__file__).parent / 'poems'
    
    # Настройки окна
    WINDOW_WIDTH = 700
    WINDOW_HEIGHT = 600
    
    @classmethod
    def is_api_available(cls):
        """Проверяет, доступен ли API ключ."""
        return bool(cls.OPENWEATHER_API_KEY)
    
    @classmethod
    def print_api_status(cls):
        # Выводит статус API ключа.
        if not cls.is_api_available():
            print("\n" + "="*50)
            print("API ключ OpenWeatherMap не найден!")
            print("="*50)
            print("Приложение будет работать БЕЗ учета погоды.")
            print("\n Чтобы включить погоду:")
            print("   1. Получите бесплатный ключ на https://openweathermap.org/api")
            print("   2. Создайте файл .env в папке с программой")
            print("   3. Добавьте в него строку: OPENWEATHER_API_KEY=ваш_ключ")
            print("   (или задайте переменную окружения)")
            print("="*50 + "\n")